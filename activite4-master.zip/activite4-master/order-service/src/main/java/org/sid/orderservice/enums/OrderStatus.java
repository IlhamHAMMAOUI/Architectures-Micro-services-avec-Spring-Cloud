package org.sid.orderservice.enums;

public enum OrderStatus {
    CREATED,PENDING,DELIVERED,CANCELED
}
